package funcoes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import utils.Conexao;

public class taskTypes {
	private String tipoTarefa;
        private String descricao;
        private int total;

	// Inclusão de Departamento
	public boolean incluirTaskType() throws ClassNotFoundException {
		String sql = "INSERT INTO tarefat (Tipo_Taref, Descricao) ";
		sql += "VALUES (?,?)";
		Connection con = Conexao.conectar();
		try {
			PreparedStatement stm = con.prepareStatement(sql);
			stm.setString(1, this.getTipoTarefa());
                        stm.setString(2, this.getDescricao());
			stm.execute();
		} catch (SQLException e) {
			System.out.println("Erro na inclusão do tipo de tarefa");
			return false;
		}
		return true;
	}
	public boolean alterarDesc() throws ClassNotFoundException {
		String  sql = "UPDATE tarefat ";
				sql += "SET Desc = ? ";
				sql += "WHERE Tipo_Taref = ? ";
		Connection con = Conexao.conectar();
		try {
			PreparedStatement stm = con.prepareStatement(sql);
			stm.setString(1, this.getDescricao());
			stm.setString(2, this.getTipoTarefa());
			stm.execute();
		} catch (SQLException e) {
			System.out.println("Erro na alteração do departamento");
			return false;
		}
		return true;
	}
            public List<taskTypes> ListaTaskType() throws ClassNotFoundException {
        List<taskTypes> taskTypeList = new ArrayList<>();
        String sql = "SELECT * FROM tarefat"; // Nome correto da tabela (ajuste conforme necessário)
        
        try (Connection con = Conexao.conectar(); // Supondo que a classe Conexao gerencie a conexão
             PreparedStatement stm = con.prepareStatement(sql);
             ResultSet rs = stm.executeQuery()) {
            
            while (rs.next()) {
                taskTypes taskType = new taskTypes();
                taskType.setTipoTarefa(rs.getString("Tipo_Taref")); // Ajuste de acordo com o nome da coluna
                taskType.setDescricao(rs.getString("Descricao")); // Ajuste de acordo com o nome da coluna
                taskTypeList.add(taskType);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar tipos de tarefa: " + e.getMessage());
            e.printStackTrace();
        }
        
        return taskTypeList;
    }
        public boolean NumeroL() throws ClassNotFoundException {
                String sql = "select count(*) from tarefat";
                Connection con = Conexao.conectar();
		try {
			PreparedStatement stm = con.prepareStatement(sql);
			stm.execute();
		} catch (SQLException e) {
			System.out.println("Erro na alteração do departamento");
			return false;
		}
		return true;
        }
        public boolean excluirTaskType() throws ClassNotFoundException {
			String  sql  = "DELETE FROM tarefat ";
					sql += "WHERE tipoTarefa = ? ";
			Connection con = Conexao.conectar();
			try {
				PreparedStatement stm = con.prepareStatement(sql);
				stm.setString(1, this.getTipoTarefa());
				stm.execute();
			} catch (SQLException e) {
				System.out.println("Erro na exclusão do departamento");
				return false;
			}
			return true;
		}	
        


	// area de getters e setters
	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getTipoTarefa() {
		return tipoTarefa;
	}

	public void setTipoTarefa(String tipoTarefa) {
		this.tipoTarefa = tipoTarefa;
	}

 

    /**
     * @return the Total
     */
    public int getTotal() {
        return total;
    }

    /**
     * @param Total the Total to set
     */
    public void setTotal(int total) {
        this.total = total;
    }

}