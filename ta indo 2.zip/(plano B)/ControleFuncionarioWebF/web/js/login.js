document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("login-form");
    let users = JSON.parse(localStorage.getItem('users')) || [];
    let developers = JSON.parse(localStorage.getItem('developers')) || [];

    loginForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const username = loginForm[0].value.trim();
        const password = loginForm[1].value.trim();

        // Verifica se o usuário ou desenvolvedor existe
        const user = users.find(user => user.username.toLowerCase() === username.toLowerCase() && user.password === password);
        const developer = developers.find(dev => dev.name.toLowerCase() === username.toLowerCase() && dev.password === password);

        if (user) {
            alert("Login de usuário realizado com sucesso!");
            window.location.href = "tasks.html"; // Redireciona para a página de tarefas
        } else if (developer) {
            alert("Login de desenvolvedor realizado com sucesso!");
            window.location.href = "tasks.html"; // Redireciona para a página de tarefas
        } else {
            alert("Usuário ou senha incorretos.");
        }
    });
});
