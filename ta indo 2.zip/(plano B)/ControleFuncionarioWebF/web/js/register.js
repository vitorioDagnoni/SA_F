document.addEventListener("DOMContentLoaded", () => {
    const registerForm = document.getElementById("register-form");
    let users = JSON.parse(localStorage.getItem('users')) || [];

    registerForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const username = document.getElementById("username").value.trim();
        const password = document.getElementById("password").value.trim();

        if (username && password) {
            // Verificar se o usuário já existe
            const existingUser = users.find(user => user.username.toLowerCase() === username.toLowerCase());
            if (existingUser) {
                alert("Usuário já existe. Tente outro nome.");
                return;
            }

            const newUser = { username, password };
            users.push(newUser);
            localStorage.setItem('users', JSON.stringify(users));
            alert("Cadastro realizado com sucesso! Você pode fazer login agora.");
            window.location.href = "login.html"; // Redirecionar para a página de login
        } else {
            alert("Por favor, preencha todos os campos.");
        }
    });
});
