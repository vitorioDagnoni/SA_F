document.addEventListener("DOMContentLoaded", () => {
    const developerForm = document.getElementById("developer-form");
    let developers = JSON.parse(localStorage.getItem('developers')) || [];
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

    // Atualiza a tabela de desenvolvedores ao carregar
    displayDevelopers();

    developerForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const developerName = document.getElementById("developerName").value.trim();
        const developerPassword = document.getElementById("developerPassword").value.trim();

        if (developerName && developerPassword) {
            // Verifica se o desenvolvedor já existe
            const existingDeveloper = developers.find(dev => dev.name === developerName);
            if (existingDeveloper) {
                alert("Desenvolvedor já existe. Tente outro nome.");
                return;
            }

            const newDeveloper = {
                id: developers.length + 1,
                name: developerName,
                password: developerPassword,
                blocked: false // Inicialmente não bloqueado
            };

            developers.push(newDeveloper);
            localStorage.setItem('developers', JSON.stringify(developers));
            displayDevelopers();
            developerForm.reset();
            alert("Cadastro realizado com sucesso! O desenvolvedor pode fazer login agora.");
        } else {
            alert("Por favor, preencha todos os campos.");
        }
    });

    function displayDevelopers() {
        const developerTableBody = document.getElementById("developer-table-body");
        developerTableBody.innerHTML = developers.map(developer => {
            const developerTasks = tasks.filter(task => task.developerId === developer.id);
            const taskList = developerTasks.length > 0 ? `<button class="view-tasks-button" data-id="${developer.id}">Ver Tarefas</button>` : 'Nenhuma tarefa';

            return `
                <tr>
                    <td>${developer.name}</td>
                    <td>${taskList}</td>
                    <td>
                        <select class="status-select" data-id="${developer.id}">
                            <option value="false" ${developer.blocked ? '' : 'selected'}>Desbloquear</option>
                            <option value="true" ${developer.blocked ? 'selected' : ''}>Bloquear</option>
                        </select>
                    </td>
                    <td>
                        <button class="edit-button" data-id="${developer.id}">Editar Senha</button>
                        <button class="delete-button" data-id="${developer.id}">Excluir</button>
                    </td>
                </tr>
            `;
        }).join('');

        // Adiciona eventos aos botões de visualizar tarefas, editar e excluir
        document.querySelectorAll(".view-tasks-button").forEach(button => {
            button.addEventListener("click", (e) => {
                const id = parseInt(e.target.dataset.id);
                viewTasks(id);
            });
        });

        document.querySelectorAll(".edit-button").forEach(button => {
            button.addEventListener("click", (e) => {
                const id = parseInt(e.target.dataset.id);
                editDeveloperPassword(id);
            });
        });

        document.querySelectorAll(".delete-button").forEach(button => {
            button.addEventListener("click", (e) => {
                const id = parseInt(e.target.dataset.id);
                deleteDeveloper(id);
            });
        });

        document.querySelectorAll(".status-select").forEach(select => {
            select.addEventListener("change", (e) => {
                const id = parseInt(e.target.dataset.id);
                const isBlocked = e.target.value === 'true';
                updateDeveloperStatus(id, isBlocked);
            });
        });
    }

    function viewTasks(developerId) {
        const developerTasks = tasks.filter(task => task.developerId === developerId);
        const modalTaskContainer = document.getElementById("modal-task-container");
        modalTaskContainer.innerHTML = ''; // Limpa tarefas anteriores

        if (developerTasks.length === 0) {
            modalTaskContainer.innerHTML = `<p>Nenhuma tarefa encontrada para este desenvolvedor.</p>`;
        } else {
            developerTasks.forEach(task => {
                const taskCard = document.createElement('div');
                taskCard.className = 'task-card';
                taskCard.innerHTML = `
                    <h3>${task.name}</h3>
                    <p>Status: ${task.status}</p>
                    <button class="delete-task-button" data-id="${task.id}">Excluir Tarefa</button>
                `;
                modalTaskContainer.appendChild(taskCard);
            });
        }

        const modal = document.getElementById("task-modal");
        modal.style.display = "block";

        // Adiciona evento para excluir tarefa
        modalTaskContainer.querySelectorAll('.delete-task-button').forEach(button => {
            button.addEventListener('click', (e) => {
                const taskId = parseInt(e.target.dataset.id);
                deleteTask(taskId);
                viewTasks(developerId); // Atualiza as tarefas no modal
            });
        });

        document.querySelector(".close-button").onclick = function() {
            modal.style.display = "none";
        };

        window.onclick = function(event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        };
    }

    function editDeveloperPassword(id) {
        const newPassword = prompt("Digite a nova senha:");
        if (newPassword) {
            const developerIndex = developers.findIndex(dev => dev.id === id);
            if (developerIndex > -1) {
                developers[developerIndex].password = newPassword;
                localStorage.setItem('developers', JSON.stringify(developers));
                alert("Senha editada com sucesso!");
                displayDevelopers();
            }
        }
    }

    function deleteDeveloper(id) {
        developers = developers.filter(dev => dev.id !== id);
        localStorage.setItem('developers', JSON.stringify(developers));
        displayDevelopers();
        alert("Desenvolvedor excluído com sucesso!");
    }

    function updateDeveloperStatus(id, isBlocked) {
        const developerIndex = developers.findIndex(dev => dev.id === id);
        if (developerIndex > -1) {
            developers[developerIndex].blocked = isBlocked;
            localStorage.setItem('developers', JSON.stringify(developers));
            alert(isBlocked ? "Desenvolvedor bloqueado!" : "Desenvolvedor desbloqueado!");
        }
    }

    function deleteTask(id) {
        tasks = tasks.filter(task => task.id !== id);
        localStorage.setItem('tasks', JSON.stringify(tasks));
        alert("Tarefa excluída com sucesso!");
    }
});
