package funcoes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import utils.Conexao;

public class task {
	private String nomeTarefa;
        private String nomeUsu;
        private String tipoTarefa;
        private String statusTarefa;
        private int total;

	// Inclusão de Departamento
	public boolean incluirTask() throws ClassNotFoundException {
		String sql = "INSERT INTO tarefas (Nome_Usuario, Nome_Taref, Tipo_Taref, Status_Taref) ";
		sql += "VALUES (?,?,?,?)";
		Connection con = Conexao.conectar();
		try {
			PreparedStatement stm = con.prepareStatement(sql);
                        stm.setString(1, this.getNomeUsu());
			stm.setString(2, this.getNomeTarefa());
                        stm.setString(3, this.getTipoTarefa());
                        stm.setString(4, this.getStatusTarefa());
                        
			stm.execute();
		} catch (SQLException e) {
			System.out.println("Erro na inclusão do departamento");
			return false;
		}
		return true;
	}
	public boolean alterarTask() throws ClassNotFoundException {
		String  sql = "UPDATE tarefas ";
				sql += "SET Nome_Usuario = ?, Tipo_Taref = ?, Status_Taref = ?";
				sql += "WHERE Nome_Taref = ? ";
		Connection con = Conexao.conectar();
		try {
			PreparedStatement stm = con.prepareStatement(sql);
			stm.setString(1, this.getNomeUsu());
                        stm.setString(2, this.getTipoTarefa());
                        stm.setString(3, this.getStatusTarefa());
			stm.setString(4, this.getNomeTarefa());
			stm.execute();
		} catch (SQLException e) {
			System.out.println("Erro na alteração do departamento");
			return false;
		}
		return true;
	}
        public boolean ListaTask() throws ClassNotFoundException {
                String sql = "SELECT * FROM tarefas";
                sql += "LIMIT ?,1";
                Connection con = Conexao.conectar();
		try {
			PreparedStatement stm = con.prepareStatement(sql);
                        stm.setInt(1, this.getTotal());
			stm.execute();
		} catch (SQLException e) {
			System.out.println("Erro na alteração do departamento");
			return false;
		}
		return true;
        }
        public boolean NumeroL() throws ClassNotFoundException {
                String sql = "select count(*) from tarefas";
                Connection con = Conexao.conectar();
		try {
			PreparedStatement stm = con.prepareStatement(sql);
			stm.execute();
		} catch (SQLException e) {
			System.out.println("Erro na alteração do departamento");
			return false;
		}
		return true;
        }
        public boolean excluirTask() throws ClassNotFoundException {
			String  sql  = "DELETE FROM tarefas ";
					sql += "WHERE Nome_taref = ? ";
			Connection con = Conexao.conectar();
			try {
				PreparedStatement stm = con.prepareStatement(sql);
				stm.setString(1, this.getNomeTarefa());
				stm.execute();
			} catch (SQLException e) {
				System.out.println("Erro na exclusão do departamento");
				return false;
			}
			return true;
		}	


	// area de getters e setters
	public String getNomeUsu() {
		return nomeUsu;
	}

	public void setNomeUsu(String nomeUsu) {
		this.nomeUsu = nomeUsu;
	}

	public String getNomeTarefa() {
		return nomeTarefa;
	}

	public void setNomeTarefa(String nomeTarefa) {
		this.nomeTarefa = nomeTarefa;
	}

 

    /**
     * @return the Total
     */
    public int getTotal() {
        return total;
    }

    /**
     * @param Total the Total to set
     */
    public void setTotal(int total) {
        this.total = total;
    }

    /**
     * @return the tipoTarefa
     */
    public String getTipoTarefa() {
        return tipoTarefa;
    }

    /**
     * @param tipoTarefa the tipoTarefa to set
     */
    public void setTipoTarefa(String tipoTarefa) {
        this.tipoTarefa = tipoTarefa;
    }

    /**
     * @return the statusTarefa
     */
    public String getStatusTarefa() {
        return statusTarefa;
    }

    /**
     * @param statusTarefa the statusTarefa to set
     */
    public void setStatusTarefa(String statusTarefa) {
        this.statusTarefa = statusTarefa;
    }

}
