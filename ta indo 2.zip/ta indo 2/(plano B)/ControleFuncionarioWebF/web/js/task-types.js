document.addEventListener("DOMContentLoaded", () => {
    const taskTypeForm = document.getElementById("task-type-form");
    const taskTypeNameInput = document.getElementById("task-type-name");
    const searchTaskTypeInput = document.getElementById("search-task-type-input");  // Barra de pesquisa
    let taskTypes = JSON.parse(localStorage.getItem('taskTypes')) || [];
    let editTaskTypeId = null;  // Variável para armazenar o ID do tipo de tarefa em edição

    // Atualiza a tabela de tipos de tarefa
    displayTaskTypes(taskTypes);

    taskTypeForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const taskTypeName = taskTypeNameInput.value.trim();

        if (taskTypeName) {
            // Verifica se já existe um tipo de tarefa com o mesmo nome
            const existingTaskType = taskTypes.find(type => type.name.toLowerCase() === taskTypeName.toLowerCase() && type.id !== editTaskTypeId);

            if (existingTaskType) {
                alert("Já existe um tipo de tarefa com este nome. Por favor, escolha outro nome.");
                return;
            }

            // Verifica se está editando ou criando um novo tipo de tarefa
            if (editTaskTypeId) {
                // Atualiza o tipo de tarefa existente
                const taskTypeIndex = taskTypes.findIndex(type => type.id === editTaskTypeId);
                taskTypes[taskTypeIndex] = {
                    id: editTaskTypeId,
                    name: taskTypeName
                };
                editTaskTypeId = null;  // Reseta o ID de edição
                alert("Tipo de tarefa editado com sucesso!");
            } else {
                // Cria um novo tipo de tarefa
                const newTaskType = {
                    id: taskTypes.length > 0 ? taskTypes[taskTypes.length - 1].id + 1 : 1,
                    name: taskTypeName
                };
                taskTypes.push(newTaskType);
                alert("Tipo de tarefa criado com sucesso!");
            }

            localStorage.setItem('taskTypes', JSON.stringify(taskTypes));
            displayTaskTypes(taskTypes);
            taskTypeForm.reset();
        } else {
            alert("Por favor, insira o nome do tipo de tarefa.");
        }
    });

    // Adiciona funcionalidade de pesquisa
    searchTaskTypeInput.addEventListener("input", (e) => {
        const searchValue = e.target.value.toLowerCase();
        const filteredTaskTypes = taskTypes.filter(type => type.name.toLowerCase().includes(searchValue));
        displayTaskTypes(filteredTaskTypes);
    });

    function displayTaskTypes(taskTypeList) {
        const taskTypeTableBody = document.getElementById("task-type-table-body");
        taskTypeTableBody.innerHTML = taskTypeList.map(type => {
            return `
                <tr>
                    <td>${type.name}</td>
                    <td>
                        <button class="edit-button" data-id="${type.id}">Editar</button>
                        <button class="delete-button" data-id="${type.id}">Excluir</button>
                    </td>
                </tr>
            `;
        }).join('');

        // Adicionar eventos de edição e exclusão para os botões
        document.querySelectorAll(".edit-button").forEach(button => {
            button.addEventListener("click", (e) => {
                const id = parseInt(e.target.dataset.id);
                editTaskType(id);
            });
        });

        document.querySelectorAll(".delete-button").forEach(button => {
            button.addEventListener("click", (e) => {
                const id = parseInt(e.target.dataset.id);
                deleteTaskType(id);
            });
        });
    }

    function editTaskType(id) {
        const taskType = taskTypes.find(type => type.id === id);
        if (taskType) {
            taskTypeNameInput.value = taskType.name;
            editTaskTypeId = id;  // Armazena o ID do tipo de tarefa em edição
        }
    }

    function deleteTaskType(id) {
        taskTypes = taskTypes.filter(type => type.id !== id);
        localStorage.setItem('taskTypes', JSON.stringify(taskTypes));
        displayTaskTypes(taskTypes);
    }
});
