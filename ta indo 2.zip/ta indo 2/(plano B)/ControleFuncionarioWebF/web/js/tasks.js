document.addEventListener("DOMContentLoaded", () => {
    const taskForm = document.getElementById("task-form");
    const taskNameInput = document.getElementById("task-name");
    const developerSelect = document.getElementById("developer-select");
    const taskTypeSelect = document.getElementById("task-type-select");
    const searchTaskInput = document.getElementById("search-task-input");

    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    let developers = JSON.parse(localStorage.getItem('developers')) || [];
    let taskTypes = JSON.parse(localStorage.getItem('taskTypes')) || [];
    let editTaskId = null;  // Variável para armazenar o ID da tarefa em edição

    // Preenche os selects de desenvolvedores e tipos de tarefa
    populateDeveloperSelect();
    populateTaskTypeSelect();

    // Atualiza a tabela de tarefas
    displayTasks(tasks);

    taskForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const taskName = taskNameInput.value.trim();
        const developerId = parseInt(developerSelect.value);
        const taskTypeId = parseInt(taskTypeSelect.value);

        if (taskName && developerId && taskTypeId) {
            // Verifica se já existe uma tarefa com o mesmo nome
            const existingTask = tasks.find(task => task.name.toLowerCase() === taskName.toLowerCase() && task.id !== editTaskId);

            if (existingTask) {
                alert("Já existe uma tarefa com este nome. Por favor, escolha outro nome.");
                return;
            }

            // Verifica se está editando ou criando uma nova tarefa
            if (editTaskId) {
                // Atualiza a tarefa existente
                const taskIndex = tasks.findIndex(task => task.id === editTaskId);
                tasks[taskIndex] = {
                    id: editTaskId,
                    name: taskName,
                    developerId: developerId,
                    taskTypeId: taskTypeId,
                    status: "Pendente"  // Adicionando um status padrão
                };
                editTaskId = null; // Reseta o ID de edição
                alert("Tarefa editada com sucesso!");
            } else {
                // Cria uma nova tarefa
                const newTask = {
                    id: tasks.length > 0 ? tasks[tasks.length - 1].id + 1 : 1,
                    name: taskName,
                    developerId: developerId,
                    taskTypeId: taskTypeId,
                    status: "Pendente"  // Adicionando um status padrão
                };
                tasks.push(newTask);
                alert("Tarefa criada com sucesso!");
            }

            localStorage.setItem('tasks', JSON.stringify(tasks));
            displayTasks(tasks);
            taskForm.reset();
        } else {
            alert("Por favor, preencha todos os campos.");
        }
    });

    searchTaskInput.addEventListener("input", (e) => {
        const searchValue = e.target.value.toLowerCase();
        const filteredTasks = tasks.filter(task => task.name.toLowerCase().includes(searchValue));
        displayTasks(filteredTasks);
    });

    function displayTasks(taskList) {
        const taskTableBody = document.getElementById("task-table-body");
        taskTableBody.innerHTML = taskList.map(task => {
            const developer = developers.find(dev => dev.id === task.developerId);
            const taskType = taskTypes.find(type => type.id === task.taskTypeId);
            
            return `
                <tr>
                    <td>${task.name}</td>
                    <td>${developer ? developer.name : 'Desenvolvedor não encontrado'}</td>
                    <td>${taskType ? taskType.name : 'Tipo não encontrado'}</td>
                    <td>
                        <select class="status-select" data-id="${task.id}">
                            <option value="Pendente" ${task.status === 'Pendente' ? 'selected' : ''}>Pendente</option>
                            <option value="Completa" ${task.status === 'Completa' ? 'selected' : ''}>Completa</option>
                            <option value="Cancelada" ${task.status === 'Cancelada' ? 'selected' : ''}>Cancelada</option>
                        </select>
                        <div style="display: flex; flex-direction: column; gap: 5px; margin-top: 5px;">
                            <button class="edit-button" data-id="${task.id}">Editar</button>
                            <button class="delete-button" data-id="${task.id}">Excluir</button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        // Adicionar eventos para atualizar o status das tarefas
        document.querySelectorAll(".status-select").forEach(select => {
            select.addEventListener("change", (e) => {
                const id = parseInt(e.target.dataset.id);
                const newStatus = e.target.value;
                updateTaskStatus(id, newStatus);
            });
        });

        // Adicionar eventos de edição e exclusão para os botões
        document.querySelectorAll(".edit-button").forEach(button => {
            button.addEventListener("click", (e) => {
                const id = parseInt(e.target.dataset.id);
                editTask(id);
            });
        });

        document.querySelectorAll(".delete-button").forEach(button => {
            button.addEventListener("click", (e) => {
                const id = parseInt(e.target.dataset.id);
                deleteTask(id);
            });
        });
    }

    function populateDeveloperSelect() {
        developerSelect.innerHTML = developers.map(dev => {
            return `<option value="${dev.id}">${dev.name}</option>`;
        }).join('');
    }

    function populateTaskTypeSelect() {
        taskTypeSelect.innerHTML = taskTypes.map(type => {
            return `<option value="${type.id}">${type.name}</option>`;
        }).join('');
    }

    function editTask(id) {
        const task = tasks.find(t => t.id === id);
        if (task) {
            taskNameInput.value = task.name;
            developerSelect.value = task.developerId;
            taskTypeSelect.value = task.taskTypeId;
            editTaskId = id;  // Armazena o ID da tarefa em edição
        }
    }

    function deleteTask(id) {
        tasks = tasks.filter(task => task.id !== id);
        localStorage.setItem('tasks', JSON.stringify(tasks));
        displayTasks(tasks);
    }

    function updateTaskStatus(id, status) {
        const taskIndex = tasks.findIndex(task => task.id === id);
        if (taskIndex !== -1) {
            tasks[taskIndex].status = status;
            localStorage.setItem('tasks', JSON.stringify(tasks));
        }
    }
});
